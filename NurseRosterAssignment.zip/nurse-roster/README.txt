Nurse Roster Group Assignment:

Group Members:
James Dahms - 2760619
Phil Ward - s2847153

This Java project uses CSP to solve a roster problem. A user can set up wards that contain nurses.
This app can generate a nurse roster for the wards using certain contstraints which can be modified for each ward.
