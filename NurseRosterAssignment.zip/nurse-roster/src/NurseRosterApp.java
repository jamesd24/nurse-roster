import WardsWindow.WardsWindowMain;

/**
 * Created with IntelliJ IDEA.
 * User: James
 * Date: 9/19/13
 * Time: 1:17 PM
 * Main NurseRoster program starts a new WardsWindowMain.
 */
public class NurseRosterApp {
    public static void main(String[] args) {
           WardsWindowMain run = new WardsWindowMain();

    }
}
